package com.alfaztech.chatapp.activities;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.alfaztech.chatapp.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class SettingActivity extends AppCompatActivity {

    ListView list;
    String[] web = {
            "Account",
            "Chats",
            "Notification",
            "Invite a friend",
            "Data & Storage Usage",
            "Help"
    } ;
    Integer[] imageId = {
            R.drawable.account1,
            R.drawable.chat,
            R.drawable.notification,
            R.drawable.invitefriend,
            R.drawable.stoerge,
            R.drawable.help
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CircleImageView circleImageView=findViewById(R.id.profile_pic);
        TextView textView_username=findViewById(R.id.profile_username);
        TextView textView_status=findViewById(R.id.profile_status);
        setContentView(R.layout.list);
        CustomList listAdapter = new
                CustomList(SettingActivity.this, web, imageId);
        list=(ListView)findViewById(R.id.list_view);
        list.setAdapter(listAdapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Toast.makeText(SettingActivity.this, "You Clicked at " +web[+ position], Toast.LENGTH_SHORT).show();
                    if(position==0){
                        Intent intent=new Intent(view.getContext(),Account.class);
                        startActivity(intent);
                    }
                if (position==3) {
                    Intent intent_invite = new Intent(Intent.ACTION_SEND);
                    intent_invite.setType("invite friends");
                    String sharebody = "your body here";
                    String sharesub = "your subject";
                    intent_invite.putExtra(Intent.EXTRA_SUBJECT, sharesub);
                    intent_invite.putExtra(Intent.EXTRA_TEXT, sharebody);
                    startActivity(Intent.createChooser(intent_invite, "share using"));
                }
                if (position==4){
                        Intent intent_Data=new Intent(getApplicationContext(),DataStorage.class);
                        startActivity(intent_Data);
                }
                if (position==5){
                    Intent intent_help=new Intent(getApplicationContext(),Help.class);
                    startActivity(intent_help);
                }
            }
        });
    }
}

