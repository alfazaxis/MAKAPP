package com.alfaztech.chatapp.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.alfaztech.chatapp.R;

public class Account extends AppCompatActivity {
    ListView list1;
    String[] web = {
            "Privacy",
            "Security",
            "Two-Step verification",
            "Change Number",
            "Delete Number"
    } ;
    Integer[] imageId = {
            R.drawable.privacy,
            R.drawable.security,
            R.drawable.twostep,
            R.drawable.changenumber,
            R.drawable.deleteaccount
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        setContentView(R.layout.list);
        CustomListAccount listAdapter = new
                CustomListAccount(Account.this, web, imageId);
        list1=(ListView)findViewById(R.id.list_view);
        list1.setAdapter(listAdapter);
        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if(position==0){
                    Intent intent=new Intent(view.getContext(),Privacy.class);
                    startActivity(intent);
                }
                // For Security     which coming soon
               /* if(position==1){
                    Toast.makeText(this,"coming soon",Toast.LENGTH_SHORT).show();
                }*/
                //For Two-step Verification
                if(position==2){
                    Intent intent=new Intent(view.getContext(),TwoStepVer.class);
                    startActivity(intent);
                }
                // For Change Account Number
                if(position==3){
                    Intent intent=new Intent(view.getContext(),ChangeNumber.class);
                    startActivity(intent);
                }
                // For Delete Account
                if(position==4){
                    Intent intent=new Intent(view.getContext(),DeleteAccount.class);
                    startActivity(intent);
                }
            }
        });
    }
}
