package com.alfaztech.chatapp.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.alfaztech.chatapp.R;

public class Help extends AppCompatActivity {
    ListView list1;
    String[] web={
            "FAQ",
            "Contact us",
            "Terms & Privacy Policy ",
            "App Information"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        CustomListHelp listAdapter=new CustomListHelp(Help.this, web);
        list1=findViewById(R.id.list_first);
        list1.setAdapter(listAdapter);
        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(Help.this, "You Clicked at " +web[+ position], Toast.LENGTH_SHORT).show();
            }
        });
    }

}
