package com.alfaztech.chatapp.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.alfaztech.chatapp.BuildConfig;
import com.alfaztech.chatapp.R;
import com.alfaztech.chatapp.adapters.ContactAdapter;

/**
 * Created by alfazraza on 3/27/18.
 */

public class Tab3Contact extends Fragment {
    private static final int REQUEST_PERMISSON = 2001;

     @Override
    public void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
     }
    /*
      The fragment argument representing the section number for this
      fragment.
     */
    public static class PlaceholderFragment extends Fragment implements
            LoaderManager.LoaderCallbacks<Cursor> {

        private static final int LOADER_ID = 1;
        private RecyclerView mWhatsappRecycler;
        private ContactAdapter mContactAdapter;
        private static final String ARG_SECTION_NUMBER = "section_number";
        private View mRootView;

        private static final String[] FROM_COLUMN = {
                ContactsContract.Data.CONTACT_ID,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ?
                        ContactsContract.Data.DISPLAY_NAME_PRIMARY : ContactsContract.Data.DISPLAY_NAME,
                ContactsContract.Data.PHOTO_ID
        };
        private Bundle mBuldle;

        public PlaceholderFragment() {
        }

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static PlaceholderFragment newInstance(int sectionNumber) {
            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        // fir changig layout in fragments chnage R.layout.xxxxx
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            mRootView = inflater.inflate(R.layout.tab3contact, container, false);
            mBuldle = savedInstanceState;
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_CONTACTS) !=
                    PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(getActivity(), new String[]{
                                Manifest.permission.READ_CONTACTS},
                        REQUEST_PERMISSON
                );
            } else {

                getLoaderManager().initLoader(LOADER_ID, savedInstanceState, this);


            }
            init();
            return mRootView;
        }

        @Override
        public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);

            if (requestCode == REQUEST_PERMISSON) {
                if (grantResults.length != 0) {
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        getLoaderManager().initLoader(LOADER_ID, mBuldle, this);
                    } else {
                        getActivity().finish();
                    }
                }
            }
        }

        private void init() {
            mWhatsappRecycler = mRootView.findViewById(R.id.whatsapp_recycler);
            mWhatsappRecycler.setLayoutManager(new LinearLayoutManager(getContext()));
            mWhatsappRecycler.setHasFixedSize(true);
            mContactAdapter = new ContactAdapter(getContext(), null, ContactsContract.Data.CONTACT_ID);
            mWhatsappRecycler.setAdapter(mContactAdapter);

        }


        @Override
        public Loader<Cursor> onCreateLoader(int id, Bundle args) {
            switch (id) {
                case LOADER_ID:
                    return new CursorLoader(
                            getContext(), ContactsContract.Data.CONTENT_URI,
                            FROM_COLUMN,
                            null,
                            null, (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ?
                            ContactsContract.Data.DISPLAY_NAME_PRIMARY : ContactsContract.Data.DISPLAY_NAME)
                    );
                default:
                    if (BuildConfig.DEBUG)
                        throw new IllegalArgumentException("no id handled!");
                    return null;
            }
        }

        @Override
        public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
            mContactAdapter.swapCursor(data);
        }

        @Override
        public void onLoaderReset(Loader<Cursor> loader) {
            mContactAdapter.swapCursor(null);
        }

    }

}

