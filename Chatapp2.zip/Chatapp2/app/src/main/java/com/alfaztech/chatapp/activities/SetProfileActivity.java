package com.alfaztech.chatapp.activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alfaztech.chatapp.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class SetProfileActivity extends Activity {

    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    private ImageView ivImage;
    private String userChoosenTask;
    private TextView textView;
    private EditText editText;
    private TextView about_text;
    private EditText about_edit;
    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Toast.makeText(this,"OnCreate",Toast.LENGTH_SHORT).show();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_profile);
        ImageButton btnSelect = findViewById(R.id.btnSelectPhoto);
        btnSelect.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                selectImage();
            }
        });
        ivImage = findViewById(R.id.img);
         editText =  findViewById(R.id.edit_name);
        final Button botton = findViewById(R.id.save_name);
         textView = findViewById(R.id.set_name);
         about_text = findViewById(R.id.about_tv);
         about_edit = findViewById(R.id.about_et);
        final Button about_btn = findViewById(R.id.about_save);
        final TextView about=findViewById(R.id.about);
        final RelativeLayout relativeLayout=findViewById(R.id.relativeLayout3);
        final ImageButton imageButton =  findViewById(R.id.editpen);
        final Button nextButton=findViewById(R.id.next_button);

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
                nextButton.setVisibility(View.INVISIBLE);
            }
        });


        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preferences = getApplicationContext().getSharedPreferences("user",0);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("username", editText.getText().toString());
                editor.apply();
                textView.setText(preferences.getString("username","Name"));

                imageButton.setVisibility(View.INVISIBLE);
                editText.setVisibility(View.VISIBLE);
                botton.setVisibility(View.VISIBLE);
                textView.setVisibility(View.INVISIBLE);
                about_edit.setVisibility(View.INVISIBLE);
                about_btn.setVisibility(View.INVISIBLE);
                about_text.setVisibility(View.INVISIBLE);
                about.setVisibility(View.INVISIBLE);
                relativeLayout.setVisibility(View.INVISIBLE);


            }
        });
        botton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView.setText(editText.getText().toString());
                botton.setVisibility(View.INVISIBLE);
                editText.setVisibility(View.INVISIBLE);
                imageButton.setVisibility(View.VISIBLE);
                textView.setVisibility(View.VISIBLE);
                about_text.setVisibility(View.VISIBLE);
                relativeLayout.setVisibility(View.VISIBLE);
                about.setVisibility(View.VISIBLE);
            }

        });

        about_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preferences = getApplicationContext().getSharedPreferences("user",0);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("userstatus", about_edit.getText().toString());
                editor.apply();
                about_text.setText(preferences.getString("userstatus","status"));
                about_edit.setVisibility(View.VISIBLE);
                about_btn.setVisibility(View.VISIBLE);
                about_text.setVisibility(View.INVISIBLE);
                editText.setVisibility(View.INVISIBLE);
                botton.setVisibility(View.INVISIBLE);
                textView.setVisibility(View.VISIBLE);
                imageButton.setVisibility(View.VISIBLE);
                about_edit.setText(about_text.getText().toString());


            }
        });
        about_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                about_text.setText(about_edit.getText().toString());
                about_btn.setVisibility(View.INVISIBLE);
                about_edit.setVisibility(View.INVISIBLE);
                about_text.setVisibility(View.VISIBLE);
            }

        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case Utility.MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if(userChoosenTask.equals("Take Photo"))
                        cameraIntent();
                    else if(userChoosenTask.equals("Choose from Galllary"))
                        galleryIntent();
                } else {
                    //code for deny
                }
                break;
        }
    }

    private void selectImage() {
        final CharSequence[] items = { "Take Photo", "Choose from Gallary",
                "Remove Photo" };

        AlertDialog.Builder builder = new AlertDialog.Builder(SetProfileActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                boolean result=Utility.checkPermission(SetProfileActivity.this);

                if (items[item].equals("Take Photo")) {
                    userChoosenTask ="Take Photo";
                    if(result)
                        cameraIntent();

                } else if (items[item].equals("Choose from Gallary")) {
                    userChoosenTask ="Choose from Gallary";
                    if(result)
                        galleryIntent();

                } else if (items[item].equals("Remove Photo")) {
                    Resources res=getResources();
                    ivImage.setImageDrawable(res.getDrawable(R.drawable.my_image));
                }
            }
        });
        builder.show();
    }

    private void galleryIntent()
    {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"),SELECT_FILE);
    }

    private void cameraIntent()
    {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAMERA);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE)
                onSelectFromGalleryResult(data);
            else if (requestCode == REQUEST_CAMERA)
                onCaptureImageResult(data);
        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);

        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");

        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        ivImage.setImageBitmap(thumbnail);
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {

        Bitmap bm=null;
        if (data != null) {
            try {
                bm = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        ivImage.setImageBitmap(bm);
    }

    @Override
    protected void onPause() {
        textView = findViewById(R.id.set_name);
        about_text = findViewById(R.id.about_tv);
        preferences = getApplicationContext().getSharedPreferences("user",0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("username", editText.getText().toString());
        editor.apply();
        textView.setText(preferences.getString("username","Name"));
        editor.putString("userstatus", about_edit.getText().toString());
        editor.apply();
        about_text.setText(preferences.getString("userstatus","status"));
        super.onPause();
    }

    @Override
    protected void onResume() {
        textView = findViewById(R.id.set_name);
        about_text = findViewById(R.id.about_tv);
        preferences = getApplicationContext().getSharedPreferences("user",0);
        textView.setText(preferences.getString("username","Name"));
        about_text.setText(preferences.getString("userstatus","status"));
        super.onResume();
    }
    @Override
    protected void  onDestroy(){
        textView = findViewById(R.id.set_name);
        about_text = findViewById(R.id.about_tv);
        preferences = getApplicationContext().getSharedPreferences("user",0);
        textView.setText(preferences.getString("username","Name"));
        about_text.setText(preferences.getString("userstatus","status"));
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        textView = findViewById(R.id.set_name);
        about_text = findViewById(R.id.about_tv);
        preferences = getApplicationContext().getSharedPreferences("user",0);
        textView.setText(preferences.getString("username","Name"));
        about_text.setText(preferences.getString("userstatus","status"));
        super.onStop();
    }

    @Override
    public void onBackPressed(){

        Intent backIntent=new Intent(getApplication(),MainActivity.class);
        startActivity(backIntent);
        // Toast 2 back

    }
}