package com.alfaztech.chatapp.activities;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.alfaztech.chatapp.R;

import java.util.List;

/**
 * Created by alfazraza on 3/16/18.
 */

public class ListAdapter extends BaseAdapter {
    private Context context;
    private List<list> mlist;

    //constructor

    public ListAdapter(Context context, List<list> mlist) {
        this.context = context;
        this.mlist = mlist;
    }

    @Override
    public int getCount() {
        return mlist.size();
    }

    @Override
    public Object getItem(int position) {
        return mlist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v=View.inflate(context,R.layout.item_list_privacy,null);
        TextView tv=(TextView)v.findViewById(R.id.item_name);
        TextView tv1=(TextView)v.findViewById(R.id.item_des);

        //set text for textview
        tv.setText(mlist.get(position).getName());
        tv1.setText(String.valueOf(mlist.get(position).getName()));

        //save list id to tag
        v.setTag(mlist.get(position).getId());
        return v;
    }
}
