package com.alfaztech.chatapp.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.alfaztech.chatapp.R;

public class DataStorage extends AppCompatActivity {
    ListView list1;
    String[] web={
            "Network Usage",
            "Storage Usage"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_storage);
        CustomListStorage listAdapter=new CustomListStorage(DataStorage.this, web);
        list1=findViewById(R.id.list_first);
        list1.setAdapter(listAdapter);
        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(DataStorage.this, "You Clicked at " +web[+ position], Toast.LENGTH_SHORT).show();
            }
        });
    }
}
