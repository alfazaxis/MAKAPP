package com.alfaztech.chatapp.activities;

        import android.content.DialogInterface;
        import android.content.Intent;
        import android.support.v7.app.AlertDialog;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.AdapterView;
        import android.widget.ListAdapter;
        import android.widget.ListView;
        import android.widget.Toast;

        import com.alfaztech.chatapp.R;

        import java.util.ArrayList;
        import java.util.List;
public class Privacy extends AppCompatActivity {

    private ListAdapter adapter;
    private List<list> mlist;
    String[] name={"Everyone","My Contacts","Nobody"};
    String[] list2 = new String[]{"Last seen","Profile photo","About","Status","Live Location"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy);

        ListView list= findViewById(R.id.list_privacy);
        mlist=new ArrayList<>();
        //Add simple data for list
        // here you can recieve cata from DB
        mlist.add(new list(1,"Last seen","Everyone"));
        mlist.add(new list(2,"Profile photo","Everyone"));
        mlist.add(new list(3,"About","Everyone"));
        mlist.add(new list(4,"Status","My contacts"));
        mlist.add(new list(5,"Live location","None"));

        //init Adapter
        adapter = new com.alfaztech.chatapp.activities.ListAdapter(Privacy.this,mlist);
        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                //For last Seen Module
                if(position==0) {

                    final AlertDialog.Builder builder=new AlertDialog.Builder(Privacy.this);
                    //builder.setMessage("This is Alert Dialog");
                    builder.setTitle("Last Seen");

                    //Single Choice items with Radio Button

                    builder.setSingleChoiceItems(name, -1,null);
                    builder.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //Toast.makeText(Privacy.this,"ok",Toast.LENGTH_SHORT).show();
                        }
                    });
                    //Avoid Multiple Button
                    //builder.setNegativeButton("Exit",null);
                    AlertDialog alertDialog=builder.create();
                    alertDialog.setCancelable(false);
                    alertDialog.show();
                }
                //For Profile Photo
                if(position==1){
                    final AlertDialog.Builder builder=new AlertDialog.Builder(Privacy.this);
                    //builder.setMessage("This is Alert Dialog");
                    builder.setTitle("Profile Photo");

                    //Single Choice items with Radio Button

                    builder.setSingleChoiceItems(name, -1,null);
                    builder.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //Toast.makeText(Privacy.this,"ok",Toast.LENGTH_SHORT).show();
                        }
                    });
                    //Avoid Multiple Button
                    //builder.setNegativeButton("Exit",null);
                    AlertDialog alertDialog=builder.create();
                    alertDialog.setCancelable(false);
                    alertDialog.show();
                }
                //For About Module
                if(position==2){
                    final AlertDialog.Builder builder=new AlertDialog.Builder(Privacy.this);
                    //builder.setMessage("This is Alert Dialog");
                    builder.setTitle("About");

                    //Single Choice items with Radio Button

                    builder.setSingleChoiceItems(name, -1,null);
                    builder.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //Toast.makeText(Privacy.this,"ok",Toast.LENGTH_SHORT).show();
                        }
                    });
                    //Avoid Multiple Button
                    //builder.setNegativeButton("Exit",null);
                    AlertDialog alertDialog=builder.create();
                    alertDialog.setCancelable(false);
                    alertDialog.show();
                }
                // For Status
                if(position==3){
                    final AlertDialog.Builder builder=new AlertDialog.Builder(Privacy.this);
                    //builder.setMessage("This is Alert Dialog");
                    builder.setTitle("My Status");

                    //Single Choice items with Radio Button

                    builder.setSingleChoiceItems(name, -1,null);
                    builder.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //Toast.makeText(Privacy.this,"ok",Toast.LENGTH_SHORT).show();
                        }
                    });
                    //Avoid Multiple Button
                    //builder.setNegativeButton("Exit",null);
                    AlertDialog alertDialog=builder.create();
                    alertDialog.setCancelable(false);
                    alertDialog.show();
                }
            }
        });

    }
}

