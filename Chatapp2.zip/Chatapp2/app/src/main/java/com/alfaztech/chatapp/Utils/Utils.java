package com.alfaztech.chatapp.Utils;

import android.content.Context;
import android.support.annotation.StringRes;
import android.widget.Toast;

/**
 * Created by alfazraza on 2/21/18.
 */

public class Utils {
    public static void showToast(Context context, String messages){
            Toast.makeText(context,messages, Toast.LENGTH_SHORT).show();
    }
    public static void showToast(Context context, @StringRes int messages){
        Toast.makeText(context,messages, Toast.LENGTH_SHORT).show();
    }
}
